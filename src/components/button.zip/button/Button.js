import {StyledButton} from "./Button.styles"
export default StyledButton;
