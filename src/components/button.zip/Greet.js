import React from 'react';

/*function Greet() {
  return <h1>Hello Reddie</h1>;
}   */

const Greet=()=><h1>Hello Reddie</h1>;
export default Greet;