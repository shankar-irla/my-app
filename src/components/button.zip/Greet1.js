import React,{ Component } from 'react';
export class Greet1 extends Component{
    render(){
        return <h1>Hello Reddie</h1>;
    }
}
    export default Greet1;